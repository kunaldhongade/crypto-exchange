import { Button } from 'antd';

function WalletActivity() {
  return (
    <div className="">
    
    </div>
  );
}

export default WalletActivity;